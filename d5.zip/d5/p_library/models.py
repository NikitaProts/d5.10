from django.db import models

# Create your models here.

class Author(models.Model):  
    full_name = models.TextField()  
    birth_year = models.SmallIntegerField()  
    country = models.CharField(max_length=2)

    def __str__(self):
        return "{}, {}".format(self.full_name, self.birth_year)

# class Reader(models.Model):
#     # id = models.UUIDField(default=uuid.uuid4, primary_key=True,
#     #                       verbose_name=_("Уникальный ключ"))
#     name = models.CharField(max_length=256, verbose_name=_("Имя"))

#     books = models.ManyToManyField("p_library.Book", verbose_name=_("Книги"),
#                                    through="p_library.BookReading")

#     def __str__(self):
#         return self.name

class Publisher(models.Model):
    name = models.TextField(unique=True)

    def __str__(self):
        return self.name


class Friend(models.Model):
    name = models.TextField()
    
    def __str__(self):
        return self.name
# class BookReading(models.Model):
#     # id = models.UUIDField(default=uuid.uuid4, primary_key=True,
#     #                       verbose_name=_("Уникальный ключ"))
#     book = models.ForeignKey("p_library.Book", on_delete=models.CASCADE,
#                              verbose_name=_("Книга"),
#                              related_name="bookreading_book")
#     reader = models.ForeignKey("p_library.Reader", on_delete=models.CASCADE,
#                                verbose_name=_("Читатель"),
#                                related_name="bookreading_reader")
#     completion = models.NullBooleanField(default=None,
#                                          verbose_name=_("Чтение завершено"))

#     def __str__(self):
#         return "-".join((str(self.book),
#                          str(self.reader),
#                          str(self.completion),))


class Book(models.Model):  
    ISBN = models.CharField(max_length=13)  
    title = models.TextField()  
    description = models.TextField()  
    year_release = models.SmallIntegerField()  
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
    copy_count = models.IntegerField(default=1)
    price = models.DecimalField(max_digits=30, decimal_places=2)
    publisher = models.ForeignKey(Publisher, null=True, blank=True, on_delete=models.CASCADE)
    lendedto = models.ForeignKey(Friend, null=True, blank=True, on_delete=models.CASCADE)

    def __str__(self):
        return self.title


